from django.urls import path
from app55.views import home
urlpatterns = [path('', home),]