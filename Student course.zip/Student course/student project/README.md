Simple Django Project to register Student, college and Course
